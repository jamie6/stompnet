﻿using Stomp.Net.Stomp.Commands;
using StompConnectServerClientProxy;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;

namespace StompClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StompPublisherAndSubscriber stompPublisherAndSubscriber;
        StompConnectionProperties connectionProperties = new();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string message = SendMessageTextBox.Text;

            SendMessageTextBox.Text = string.Empty;

            if (stompPublisherAndSubscriber != null)
            {
                stompPublisherAndSubscriber.SendMessage($"{NameTextBox.Text} : {message}");
            }
        }

        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = await ClientProxy.Subscribe();

                connectionProperties.User = NameTextBox.Text;

                stompPublisherAndSubscriber = new
                (
                    connectionProperties,
                    async message =>
                    {
                        await Task.Delay(500);

                        var content = Encoding.UTF8.GetString(message.Content);
                        message.Acknowledge();

                        Application.Current.Dispatcher.Invoke(new Action(() => MessagesRichTextBox.Document.Blocks.Add(new Paragraph(new Run(content)))));
                    }
                );
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
    }
}
