﻿namespace StompClient
{
    public class StompConnectionProperties
    {
        public string Host { get; set; } = "localhost";
        public int Port { get; set; } = 61613;
        public string User { get; set; } = "admin";
        public string Password { get; set; } = "admin";
        public string TopicName { get; set; } = "TestQ";



        #region Ssl Settings

        public string ServerName { get; set; } = "";
        public string ClientCertSubject { get; set; } = "";
        public string KeyStoreName { get; set; } = "My";
        public string KeyStoreLocation { get; set; } = "LocalMachine";

        #endregion
    }
}
