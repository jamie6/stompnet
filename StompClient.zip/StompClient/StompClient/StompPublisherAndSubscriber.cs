﻿using Stomp.Net;
using System;
using System.Text;

namespace StompClient
{
    public class StompPublisherAndSubscriber : IDisposable
    {
        public StompConnectionProperties StompConnectionProperties { get; set; }
        private Action<IBytesMessage> Listener { get; set; }
        private IConnection _connection;
        private IMessageConsumer _consumer;
        private ISession _session;
        private IMessageProducer _producer;

        public StompPublisherAndSubscriber(StompConnectionProperties stompConnectionProperties, Action<IBytesMessage> listener)
        {
            StompConnectionProperties = stompConnectionProperties;
            Listener = listener;

            Start();
        }

        /// <summary>Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.</summary>
        public void Dispose()
        {
            _connection?.Dispose();
            _session?.Dispose();
            _consumer?.Dispose();
        }

        private void Start()
        {
            var factory = GetConnectionFactory();

            // Create connection for both requests and responses
            _connection = factory.CreateConnection();

            // Open the connection
            _connection.Start();

            // Create session for both requests and responses
            _session = _connection.CreateSession(AcknowledgementMode.IndividualAcknowledge);

            // Create a message consumer
            IDestination sourceTopic = _session.GetTopic(StompConnectionProperties.TopicName);

            _consumer = _session.CreateConsumer(sourceTopic);
            _consumer.Listener += Listener;

            // Create a message producer
            _producer = _session.CreateProducer(sourceTopic);
            _producer.DeliveryMode = MessageDeliveryMode.Persistent;
        }

        private ConnectionFactory GetConnectionFactory()
        {
            // Create a connection factory
            var brokerUri = "tcp://" + StompConnectionProperties.Host + ":" + StompConnectionProperties.Port;

            return new(brokerUri, new()
            {
                UserName = StompConnectionProperties.User,
                Password = StompConnectionProperties.Password,
                TransportSettings =
                {
                    SslSettings =
                    {
                        ServerName = StompConnectionProperties.ServerName,
                        ClientCertSubject = StompConnectionProperties.ClientCertSubject,
                        KeyStoreName = StompConnectionProperties.KeyStoreName,
                        KeyStoreLocation = StompConnectionProperties.KeyStoreLocation
                    }
                },
                SkipDestinationNameFormatting = false, // Determines whether the destination name formatting should be skipped or not.
                SetHostHeader = false, // true, // Determines whether the host header will be added to messages or not
                HostHeaderOverride = null, // Can be used to override the content of the host header
            });
        }

        public void SendMessage(string message)
        {
            IBytesMessage bytesMessage = _session.CreateBytesMessage(Encoding.UTF8.GetBytes(message));
            bytesMessage.StompTimeToLive = TimeSpan.FromMinutes(1);
            bytesMessage.Headers["test"] = "test";
            _producer.Send(bytesMessage);
        }
    }
}
