﻿using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace StompConnectServerClientProxy
{
    public class ClientProxy
    {
        public static async Task<DataResponse> Subscribe()
        {
            using (var requestMessage = new HttpRequestMessage(HttpMethod.Get, "https://localhost:7009/StompConnect"))
            {
                HttpClient client = new HttpClient();
                requestMessage.Headers.Add("pki", "123");
                requestMessage.Headers.Add("user", "user1");

                HttpResponseMessage response = await client.SendAsync(requestMessage);
                string responseBody = await response.Content.ReadAsStringAsync();
                DataResponse content = JsonSerializer.Deserialize<DataResponse>(responseBody);

                return content;
            }
        }
    }
}