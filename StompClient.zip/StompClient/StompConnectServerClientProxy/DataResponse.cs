﻿using DataForStompProject;

namespace StompConnectServerClientProxy
{
    public class DataResponse : IDataResponse
    {
        public bool isSuccess { get; set; }
        public string message { get; set; } = string.Empty;
    }
}
