using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace StompConnectServer.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StompConnectController : ControllerBase
    {
        private readonly ILogger<StompConnectController> _logger;

        public StompConnectController(ILogger<StompConnectController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetStompConnection")]
        public DataResponse GetStompConnection()
        {
            string pki = Request.Headers["pki"];
            string user = Request.Headers["user"];


            return new DataResponse()
            {
                isSuccess = true,
                message = "localhost:61613"
            };
        }



        [HttpPost(Name = "PostStompMessage")]
        public async Task<string> PostStompMessage(string message)
        {




            return "message sent";
        }
    }
}