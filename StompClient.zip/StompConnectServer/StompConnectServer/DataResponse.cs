﻿using DataForStompProject;

namespace StompConnectServer
{
    public class DataResponse : IDataResponse
    {
        public bool isSuccess { get; set; } = false;
        public string message { get; set; } = string.Empty;
    }
}
